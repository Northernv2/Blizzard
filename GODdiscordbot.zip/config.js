exports.PREFIX = "$";
exports.OWNER_ID = "661614949080236074";
exports.Owner_Name = "Polarbare_#2660";